@extends('layouts.home-layout')

@section('main-content')
<div class="card">
    <div class="card-body">
        <p>Index Home Page</p>
    </div>
</div>
@endsection
