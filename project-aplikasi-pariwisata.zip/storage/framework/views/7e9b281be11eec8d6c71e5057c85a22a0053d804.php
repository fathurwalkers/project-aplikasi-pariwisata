<?php $__env->startPush('css'); ?>
    <style>
        .img-fix {
            width: 100%!important; /* You can set the dimensions to whatever you want */
            height: 200px!important;
            object-fit: cover!important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>

<!-- slider_area_end -->

<!-- where_togo_area_start  -->

<!-- where_togo_area_end  -->

<!-- popular_destination_area_start  -->
<!-- popular_destination_area_end  -->

<div class="popular_places_area">

    <div class="container">

        
            

            
        

        <div class="row justify-content-center">
            <div class="col-lg-6 mt-5">
                <div class="section_title text-center mb_70">
                    <h3>Destinasi Wisata</h3>
                    <p>Daftar destinasi wisata yang ada di Sulawesi Tenggara</p>
                </div>
            </div>
        </div>
        <div class="row">

            <?php $__currentLoopData = $wisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="single_place">
                    <div class="thumb">
                        <img src="<?php echo e(asset('foto')); ?>/<?php echo e($wis->wisata_header_foto); ?>" alt="" class="img img-fix">
                        <a href="#" class="prise"><?php echo e($wis->wisata_kota); ?></a>
                    </div>
                    <div class="place_info">
                        <a href="<?php echo e(route('detail-wisata', $wis->id)); ?>"><h3><?php echo e($wis->wisata_nama); ?></h3></a>
                        
                        <p><?php echo e($wis->wisata_kota); ?> / <?php echo e($wis->wisata_kelurahan); ?> / <?php echo e($wis->wisata_kecamatan); ?></p>
                        <div class="rating_days d-flex justify-content-between">
                            
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                <?php echo e($wisata->links('pagination::bootstrap-4')); ?>

            </div>
        </div>

        
    </div>
</div>








<!-- testimonial_area  -->

<!-- /testimonial_area  -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-pariwisata\resources\views/home/index.blade.php ENDPATH**/ ?>