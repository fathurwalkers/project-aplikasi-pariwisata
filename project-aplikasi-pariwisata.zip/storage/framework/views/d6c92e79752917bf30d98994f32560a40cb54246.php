<?php $__env->startSection('title', 'Daftar Produk'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="row mt-2">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-10 col-md-10 col-lg-10">
                        <h4 class="text-bold text-dark">Daftar Produk</h4>
                    </div>
                    <div class="col-sm-2 col-md-2 col-lg-2 d-flex justify-content-end mx-auto my-auto">
                        <form action="<?php echo e(route('dashboard')); ?>" method="GET">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-md rounded btn-primary shadow-sm border-1 border-light">
                                <span class="text-bold">
                                    Kembali
                                </span> 
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">

                        <!-- Main Content --> 
                        <table id="example1" class="table table-bordered" style="width:100%">

                            <thead class="thead-dark">
                                <tr>
                                    <th>No</th>
                                    <th>Nama Produk</th>
                                    <th>Harga</th>
                                    <th>Kode</th>
                                    <th>Kategori Produk</th>
                                    <th>Toko</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>

                            <tbody class="text-dark">
                                <?php $__currentLoopData = $produk_admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->iteration); ?></td>

                                    <td><?php echo e($item->produk_nama); ?></td>
                                    <td class="text-center"><?php echo e(intval($item->produk_harga)); ?></td>
                                    <td><?php echo e($item->produk_kode); ?></td>

                                    <?php if($item->kategori_id == null): ?>
                                    <td>Tidak ada Kategori</td>
                                    <?php else: ?>
                                    <td><?php echo e($item->kategori->kategori_nama); ?></td>
                                    <?php endif; ?>

                                    <?php if($item->umkm_id == null): ?>
                                    <td>Tidak ada UMKM</td>
                                    <?php else: ?>
                                    <td><?php echo e($item->umkm->umkm_nama); ?></td>
                                    <?php endif; ?>

                                    <td class="mx-auto d-flex justify-content-center">
                                        <form action="<?php echo e(route('lihat-produk', $item->id)); ?>" method="GET">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm rounded btn-info mr-1 d-flex">
                                                <i class="fas fa-info-circle my-auto"></i> &nbsp;<strong>Lihat</strong>
                                            </button>
                                        </form>
                                        

                                        <button type="button" class="btn btn-sm rounded btn-danger d-flex" data-toggle="modal" data-target="#hapus<?php echo e($item->id); ?>">
                                            <i class="fas fa-trash my-auto"></i>&nbsp;<strong>Hapus</strong>
                                        </button>
                                    </td>
                                </tr>

                                
                                <div class="modal fade" id="hapus<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h5 class="modal-title" id="exampleModalLabel">Hapus Produk</h5>
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                        </div>
                                        <form action="<?php echo e(route('hapus-produk', $item->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?> 
                                            <div class="modal-body">
                                                Apakah anda yakin ingin menghapus Produk "<?php echo e($item->produk_nama); ?>" ini?
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-primary">Ya, Hapus</button>
                                            </div>
                                        </form>
                                      </div>
                                    </div>
                                </div>
                                

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready( function () {
            $('#example1').DataTable();
        } );
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-pariwisata\resources\views/admin/daftar-produk-admin.blade.php ENDPATH**/ ?>