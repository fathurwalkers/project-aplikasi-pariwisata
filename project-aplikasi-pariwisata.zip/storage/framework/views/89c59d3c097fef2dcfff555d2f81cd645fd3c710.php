<?php $__env->startSection('title', 'Profile UKM'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="row mt-2">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <?php if(session('berhasil_login')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('berhasil_login')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-10 col-md-10 col-lg-10">
                        <h4>Profile - <?php echo e($umkm->umkm_nama); ?></h4>
                    </div>
                    <div class="col-sm-2 col-md-2 col-lg-2 d-flex justify-content-end mx-auto my-auto">
                        <form action="<?php echo e(route('dashboard')); ?>" method="GET">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-md rounded btn-primary shadow-sm border-1 border-light">
                                <span class="text-bold">
                                    Kembali
                                </span> 
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-3 col-md-3 col-lg-3">
                        <!-- Main Content --> 
                        <img src="<?php echo e(asset('foto')); ?>/<?php echo e($umkm->umkm_foto); ?>" alt="" width="200px" class="border-1 border-black img img-thumbnail ml-2">
                    </div>
                    <div class="col-sm-2 col-md-2 col-lg-2">
                        <p>
                            <span class="text-dark">Nama Toko</span><br>
                            <span class="text-dark">Kode Toko</span><br>
                            <span class="text-dark">Pemilik Toko</span><br>
                            <span class="text-dark">Info Toko</span><br>
                        </p>
                    </div>
                    <div class="col-sm-7 col-md-7 col-lg-7">
                        <p class="text-justify">
                            : &nbsp; <span class="text-dark"> <?php echo e($umkm->umkm_nama); ?> </span> <br>
                            : &nbsp; <span class="text-dark"> <?php echo e($umkm->umkm_kode); ?> </span> <br>
                            : &nbsp; <span class="text-dark"> <?php echo e($umkm->login->login_nama); ?> </span> <br>
                            : <span class="text-dark text-justify"> <?php echo e($umkm->umkm_info); ?> </span> <br>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-pariwisata\resources\views/admin/profile-umkm.blade.php ENDPATH**/ ?>