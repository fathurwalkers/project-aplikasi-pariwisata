<?php $__env->startSection('title', 'Detail Informasi Produk'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">

        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                
            </div>
        </div>

        <div class="card mb-4">

            <div class="card-header">
                <div class="row">
                    <div class="col-sm-10 col-md-10 col-lg-10">
                        <h4 class="text-bold text-dark">Informasi Produk - <?php echo e($produk->produk_nama); ?></h4>
                    </div>
                    <div class="col-sm-2 col-md-2 col-lg-2 d-flex justify-content-end mx-auto my-auto">
                        <form action="<?php echo e(route('dashboard')); ?>" method="GET">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-md rounded btn-primary shadow-sm border-1 border-light">
                                <span class="text-bold">
                                    Kembali
                                </span> 
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="card-body">

                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                        <img class="img img-responsive border-1" src="<?php echo e(asset('foto')); ?>/<?php echo e($produk->produk_headergambar); ?>" alt="" width="300px">
                    </div>
                </div>
                <div class="row d-flex justify-content-center mx-auto mt-4">
                    <div class="col-sm-4 col-md-4 col-lg-4">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Nama Produk </li>
                            <li class="list-group-item">Harga Produk </li>
                            <li class="list-group-item">Kode Produk </li>
                            <li class="list-group-item">Keterangan Produk </li>
                        </ul>
                    </div>
                    <div class="col-sm-8 col-md-8 col-lg-8">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"> : <?php echo e($produk->produk_nama); ?></li>
                            <li class="list-group-item"> : Rp. <?php echo e(number_format($produk->produk_harga, 2, ",", ".")); ?></li>
                            <li class="list-group-item"> : <?php echo e($produk->produk_kode); ?></li>
                            <li class="list-group-item"> : <?php echo $produk->produk_keterangan; ?></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-pariwisata\resources\views/admin/lihat-produk.blade.php ENDPATH**/ ?>