<?php $__env->startSection('main-content'); ?>
<div class="popular_places_area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section_title text-center mb_70 mt-4">
                    <h3>UKM Terdaftar</h3>
                    <p></p>
                </div>
            </div>
        </div>
        <div class="row">

            <?php $__currentLoopData = $umkm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="single_place">
                    <div class="thumb">
                        <img src="<?php echo e(asset('assets/pariwisata')); ?>/img/place/1.png" alt="">
                        <a href="#" class="prise"><?php echo e($item->umkm_foto); ?></a>
                    </div>
                    <div class="place_info">
                        <a href="<?php echo e(route('detail-wisata', $item->id)); ?>"><h3><?php echo e($item->umkm_nama); ?></h3></a>
                        
                        <p>Pemilik : <?php echo e($item->umkm_pemilik); ?> / <?php echo e($item->umkm_kode); ?></p>
                        <div class="rating_days d-flex justify-content-between">
                            
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                <?php echo e($umkm->onEachSide(0)->links()); ?>

            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="more_place_btn text-center">
                    <a class="boxed-btn4" href="<?php echo e(route('homepage')); ?>">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-pariwisata\resources\views/home/daftar-ukm.blade.php ENDPATH**/ ?>