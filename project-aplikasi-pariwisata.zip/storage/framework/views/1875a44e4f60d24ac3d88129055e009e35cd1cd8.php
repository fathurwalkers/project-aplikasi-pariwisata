<?php $__env->startSection('title', 'Profile Pengguna'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="row mt-2">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <?php if(session('berhasil_login')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('berhasil_login')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-10 col-md-10 col-lg-10">
                        <h4>Profile Pengguna </h4>
                    </div>
                    <div class="col-sm-2 col-md-2 col-lg-2 d-flex justify-content-end mx-auto my-auto">
                        <form action="<?php echo e(route('dashboard')); ?>" method="GET">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-md rounded btn-primary shadow-sm border-1 border-light">
                                <span class="text-bold">
                                    Kembali
                                </span> 
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-3 col-md-3 col-lg-3">
                        <!-- Main Content --> 
                        <img src="#" alt="">
                    </div>
                    <div class="col-sm-2 col-md-2 col-lg-2">
                        <p>
                            <span class="text-dark">Nama </span><br>
                            <span class="text-dark">Username </span><br>
                            <span class="text-dark">Email </span><br>
                            <span class="text-dark">Status </span><br>
                            <span class="text-dark">No. Telepon / HP </span><br>
                        </p>
                    </div>
                    <div class="col-sm-7 col-md-7 col-lg-7">
                        <p>
                            : <span class="text-dark"> <?php echo e($users->login_nama); ?> </span> <br>
                            : <span class="text-dark"> <?php echo e($users->login_username); ?> </span> <br>
                            : <span class="text-dark"> <?php echo e($users->login_email); ?> </span> <br>
                            : <button class="btn btn-sm btn-success"><?php echo e(strtoupper($users->login_status)); ?></button> <br>
                            : <span class="text-dark"> <?php echo e($users->login_telepon); ?> </span> <br>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-pariwisata\resources\views/admin/profile.blade.php ENDPATH**/ ?>