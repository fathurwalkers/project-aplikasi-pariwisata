<?php $__env->startSection('main-content'); ?>
<div class="popular_places_area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section_title text-center mb_70 mt-4">
                    <h3>Our Product</h3>
                    <p></p>
                </div>
            </div>
        </div>
        <div class="row">

            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="single_place">
                    <div class="thumb">
                        <img src="<?php echo e(asset('assets/pariwisata')); ?>/img/place/1.png" alt="">
                        <a href="#" class="prise"><?php echo e($item->wisata_kota); ?></a>
                    </div>
                    <div class="place_info">
                        <a href="<?php echo e(route('detail-wisata', $item->id)); ?>"><h3><?php echo e($item->wisata_nama); ?></h3></a>
                        
                        <p><?php echo e($item->wisata_kota); ?> / <?php echo e($item->wisata_kelurahan); ?> / <?php echo e($item->wisata_kecamatan); ?></p>
                        <div class="rating_days d-flex justify-content-between">
                            
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                <?php echo e($produk->onEachSide(0)->links()); ?>

            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="more_place_btn text-center">
                    <a class="boxed-btn4" href="<?php echo e(route('homepage')); ?>">Back</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-layout-english', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-pariwisata\resources\views/home/english/daftar-produk.blade.php ENDPATH**/ ?>